package com.learningmanagementservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learningmanagementservice.entity.ProgressTracking;
import com.learningmanagementservice.service.ProgressTrackingService;

@RestController
@RequestMapping("/api/progress")
public class ProgressTrackingController {

    @Autowired
    private ProgressTrackingService progressTrackingService;

    @PostMapping
    public ResponseEntity<ProgressTracking> trackProgress(@RequestBody ProgressTracking progressTracking) {
        ProgressTracking createdProgress = progressTrackingService.trackProgress(progressTracking);
        return new ResponseEntity<>(createdProgress, HttpStatus.CREATED);
    }

    @GetMapping("/user/{userId}/module/{moduleId}")
    public ResponseEntity<ProgressTracking> getProgress(@PathVariable Long userId, @PathVariable Long moduleId) {
        ProgressTracking progress = progressTrackingService.getProgress(userId, moduleId);
        return new ResponseEntity<>(progress, HttpStatus.OK);
    }
}

