package com.learningmanagementservice.exception;

public class LearningManagementException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LearningManagementException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	

}
