package com.learningmanagementservice.repository;

import org.springframework.data.repository.CrudRepository;

import com.learningmanagementservice.entity.Course;

public interface CourseRepository extends CrudRepository<Course,Long>{

}
