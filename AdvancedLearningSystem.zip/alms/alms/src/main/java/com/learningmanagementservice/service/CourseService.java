package com.learningmanagementservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learningmanagementservice.entity.Course;
import com.learningmanagementservice.repository.CourseRepository;

@Service
public class CourseService {

	    @Autowired
	    private CourseRepository courseRepository;

	    public Course createCourse(Course course) {
	        return courseRepository.save(course);
	    }

	    public Course getCourse(Long id) {
	        return courseRepository.findById(id).orElse(null);
	    }
	


}
