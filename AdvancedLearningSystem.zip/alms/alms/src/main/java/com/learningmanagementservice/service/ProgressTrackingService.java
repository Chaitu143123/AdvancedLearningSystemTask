package com.learningmanagementservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learningmanagementservice.entity.ProgressTracking;
import com.learningmanagementservice.repository.ProgressTrackingRepository;

@Service
public class ProgressTrackingService {

    @Autowired
    private ProgressTrackingRepository progressTrackingRepository;

    public ProgressTracking trackProgress(ProgressTracking progressTracking) {
        return progressTrackingRepository.save(progressTracking);
    }

    public ProgressTracking getProgress(Long userId, Long moduleId) {
        return progressTrackingRepository.findByUserIdAndModuleId(userId, moduleId);
    }
}

