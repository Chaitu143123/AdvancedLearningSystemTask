package com.learningmanagementservice.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.learningmanagementservice.entity.ProgressTracking;

@Repository
public interface ProgressTrackingRepository extends CrudRepository<ProgressTracking, Long> {
    ProgressTracking findByUserIdAndModuleId(Long userId, Long moduleId);
}

