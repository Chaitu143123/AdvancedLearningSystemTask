package com.learningmanagementservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learningmanagementservice.entity.Certification;
import com.learningmanagementservice.repository.CertificationRepository;

@Service
public class CertificationService {

    @Autowired
    private CertificationRepository certificationRepository;

    public Certification issueCertification(Certification certification) {
        return certificationRepository.save(certification);
    }
}
