package com.learningmanagementservice.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.learningmanagementservice.entity.Certification;

@Repository
public interface CertificationRepository extends CrudRepository<Certification, Long> {
	
	
}
    

