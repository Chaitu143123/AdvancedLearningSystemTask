package com.learningmanagementservice.alms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlmsApplication.class, args);
	}

}
