package com.learningmanagementservice.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.learningmanagementservice.entity.TrainingModule;

@Repository
public interface TrainingModuleRepository extends CrudRepository<TrainingModule, Long> {

}
