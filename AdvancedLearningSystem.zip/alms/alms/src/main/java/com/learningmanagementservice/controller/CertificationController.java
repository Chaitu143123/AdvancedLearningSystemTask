package com.learningmanagementservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learningmanagementservice.entity.Certification;
import com.learningmanagementservice.service.CertificationService;

@RestController
@RequestMapping("/api/certifications")
public class CertificationController {

    @Autowired
    private CertificationService certificationService;

    @PostMapping
    public ResponseEntity<Certification> issueCertification(@RequestBody Certification certification) {
        Certification createdCertification = certificationService.issueCertification(certification);
        return new ResponseEntity<>(createdCertification, HttpStatus.CREATED);
    }
}

